# Qianhui UI

A small shared product UI system for foundations, React components, and reusable composition patterns. Storybook is the visual catalog: open it to inspect every component and pattern without running a product application.

## Open the visual catalog

```bash
npm install
npm run storybook
```

Storybook opens at `http://localhost:6006`. Start with:

- **Foundations / Overview** for color, typography, spacing, and radius;
- **Components** for controls and individual cards;
- **Patterns** for navigation, hero, split, icon-grid, pricing, and artifact diff review compositions;
- **Examples / Sana-inspired showcase** for the full scrolling composition.

The showcase contains original placeholder content and CSS-only artwork. It does not ship Sana brand assets, copy, or product images.

## Use the package

During local development, link or install the package from its folder, then import the stylesheet once near the root of the consuming application:

```tsx
import "@qianhui/ui/styles.css";
import { Button, SplitFeature } from "@qianhui/ui";

export function ProductSection() {
  return (
    <SplitFeature
      title="Build from shared patterns"
      description="The layout stays consistent while the product owns its content."
      media={<YourProductPreview />}
      action={<Button>Continue</Button>}
    />
  );
}
```

Wrap pages that use standalone components in `qh-ui` so the foundation typography applies:

```tsx
<main className="qh-ui">...</main>
```

## Repository boundary

```text
src/foundations/   semantic visual tokens
src/components/    small reusable UI units
src/patterns/      desktop component compositions
stories/           visual examples; never exported to products
```

Put a component here when another product should reuse its appearance and behavior. Keep product-specific business objects in their product repository. Extract a new pattern after it proves useful across real screens rather than designing a universal API in advance.

## Checks

```bash
npm run typecheck
npm test
npm run build
npm run build-storybook
```
